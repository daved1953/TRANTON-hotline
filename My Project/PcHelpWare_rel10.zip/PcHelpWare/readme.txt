This viewer allow to create a server based on viewer settings.
External ip address is auto, detected with the help of uvnc.com.

server_res.: custom icon + background RGB(255,255,0) transparent

myservers: In this directory is the created server saved.
File is always saved as pchelpware_server.exe.
You best rename the exe to something more descriptive.

connections: contain the list of predefined viewers.

create_server: contain server parts,archieve,compressors and bat to generate
the server self extracting archieve.


